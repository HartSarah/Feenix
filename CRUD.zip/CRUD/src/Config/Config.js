export const DB_CONFIG = {
    apiKey: "AIzaSyDaA_nSekl2kt7B2hOia18RIXIhmqGekAg",
    authDomain: "notesapp-8a081.firebaseapp.com",
    databaseURL: "https://notesapp-8a081.firebaseio.com",
    projectId: "notesapp-8a081",
    storageBucket: "notesapp-8a081.appspot.com",
    messagingSenderId: "760078326823"
  };
 
